let express = require('express');
let mysql = require('mysql');
let app = express();
let conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'prog3'
});

conexao.connect(
    (erro) => {
        if (erro) {
            console.log('Erro ao conectar:');
            console.log(erro);
        } else {
            console.log('Conexão realizada com sucesso!');
        }
    }
);


conexao.query("SELECT * FROM contato ", 
             [1,      2,       "joão"], // parâmetros da consulta 
(erro, resultado) => {
    if (erro) {
    // Caso ocorra algum erro na consulta 
    console.log("erro!!!");
    console.log(erro);
    
    } else {
        console.log(resultado);
    }
});

app.get("/contato",(req,res) => {
    ///req.params.id;
    let id = req.query.id;
    conexao.query("SELECT * FROM contato WHERE id=?",[id],
    (erro,resultado) => {
        if(erro) {
            console.log(erro);
            res.send("Deu erro");
        } else {
            res.send(resultado);
        }
    }
    );

});

app.get("/listarContato", (req,res) => {
    conexao.query("Select * from contato", [],
    (erro, resultado) =>{
        if (erro) {
            console.log(erro);
            res.send("erro ao listar");
        }
        else {
            res.send(resultado );
        }
    })
});

app.get("/removerContato", (req,res) => {
    let id = req.query.id;
    conexao.query ("DELETE from contato where id=?", [id],
    (erro, resposta) => {
        if(erro) {
            console.log(erro);
            res.send("Erro ao remover");
        } else {
            res.send("id:" + id + "removido com sucesso!")
        }
    }
    )
});

app.get("/atualizarContato", (req,res)=>{
    let id = req.query.id;
    let nome = req.query.nome;
    let email = req.query.email;

    conexao.query("UPDATE contato SET nome=?, email=? where id=?", [nome, email, id],
    (erro, resultado) => {
        if (erro) {
            console.log(erro);
            res.send("Erro ao atualizar");
        }
        else {
            res.send("Atualizado com sucesso");
        }
    }
    )
})

app.get("/adicionarContato",(req,res) =>{
    let nome = req.query.nome;
    let email = req.query.email;
    conexao.query("INSERT INTO contato(nome,email) "+
    " VALUES(?,?)",[nome,email],(erro,resultado) =>{
        if(erro) {
            console.log(erro);
            res.send("Deu erro");
        } else {
            res.send(nome+" cadastrado com sucesso!!");
        }
    });
});


app.listen(3000);


